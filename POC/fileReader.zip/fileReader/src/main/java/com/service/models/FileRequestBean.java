package com.service.models;

import java.util.Date;

public class FileRequestBean {

	private String fileName;
	private Date timeSlot;
	
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public Date getTimeSlot() {
		return timeSlot;
	}
	public void setTimeSlot(Date timeSlot) {
		this.timeSlot = timeSlot;
	}
	
	
}
