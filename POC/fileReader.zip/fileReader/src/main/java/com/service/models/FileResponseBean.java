package com.service.models;

import java.util.List;

public class FileResponseBean {

	List<String> hotels;

	public List<String> getHotels() {
		return hotels;
	}

	public void setHotels(List<String> hotels) {
		this.hotels = hotels;
	}
	
	
}
